import DashBoard from '../components/DashBoard';
function DashBoardpage() {
  return (
    <div>
      <DashBoard/>
    </div>
  );
}

export default DashBoardpage;