import Signup from '../components/Signup';
function Signuppage() {
  return (
    <div>
      <Signup/>
    </div>
  );
}

export default Signuppage;